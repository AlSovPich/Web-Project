import datetime
import sqlalchemy
from requests import request
from .db_session import SqlAlchemyBase
from data.users import User
import json

game_size = 20
class Game(SqlAlchemyBase):
    __tablename__ = 'games'
    created_date = sqlalchemy.Column(sqlalchemy.DateTime,
                                     default=datetime.datetime.now)
    updated_date = sqlalchemy.Column(sqlalchemy.DateTime,
                                     default=datetime.datetime.now)
    content = sqlalchemy.Column(sqlalchemy.String, nullable=True)

    def to_html(self, file):
        f = open(file, "r")
        text = f.read().split(", ")
        res = []
        for elem in text:
            res += elem + "\n"
        return ().join(res)

    def make_move(self, word, file):
        f = open(file, "wr")
        if word[0] == f.read()[-1]:
            f.write(f.read().split("\n") + word)
        else:
            pass


